export default {
  theme: {
    extend: {}
  },
  plugins: []
}