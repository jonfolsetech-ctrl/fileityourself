# Legal Motions App

A front-end UI for guiding users through court motions.