export default function Home() {
  return (
    <main style={{padding:40}}>
      <h1>FileItYourself</h1>
      <p>Louisiana DIY Divorce & Custody Motions Workbook</p>
      <a href="/pricing">Get Instant Access</a>
    </main>
  )
}